# OpenSSF_Scorecard_Lab_Results
**Project:** `K_HEXSTRIKE` | **Status:** `FAIL` | **Run:** `2026-09-30T17:14:20.030944+00:00`

**Framework:** [OpenSSF Scorecard v4 (local proxy)](https://scorecard.dev/)

## Key Metrics

- **score:** `3.0`
- **max_score:** `10`
- **checks:** `[{'check': 'Branch-Protection', 'pass': False, 'score': 0}, {'check': 'CI-Tests', 'pass': False, 'score': 0}, {'check': `
- **slug:** `0x4m4/hexstrike-ai`
- **note:** `Proxy run locally. Full score requires: SCORECARD_TOKEN env + GitHub API access.`

---
_Anticloud Independent Benchmark — 2026-09-30T17:14:20.030944+00:00_