# NIST_AI_RMF_Lab_Results

**Project:** `K_HEXSTRIKE`  
**Tier:** `TIER_6_SECURITY_EVAL`  
**Slug:** `0x4m4/hexstrike-ai`  
**Commit:** `d689933ff579`  
**Run:** `2026-09-30T15:07:07.146295+00:00`  

## Isolation Environment

| Field | Value |
| ----- | ----- |
| Platform | `win32` |
| Python | `3.12.10` |
| HF model | `distilbert-base-uncased` |
| HF load time | `4.42s` |
| Inference device | `cpu` |

## Results

**Framework:** [NIST AI RMF 1.0 + GenAI Profile (NIST-AI-600-1 Jul 2024)](https://www.nist.gov/itl/ai-risk-management-framework)

Maturity: **88%** (3.5/4)

| Function | Description | Status | Score |
| -------- | ----------- | ------ | ----- |
| **GOVERN** | AI risk governance policies in place | PASS | 1/1 |
| **MAP** | AI risks identified and categorized | PASS | 1/1 |
| **MEASURE** | Metrics and benchmarks applied | PASS | 1/1 |
| **MANAGE** | Risk response and monitoring active | PASS | 0.5/1 |

---
_Anticloud Benchmark Suite — isolation log — 2026-09-30T15:07:07.146295+00:00_