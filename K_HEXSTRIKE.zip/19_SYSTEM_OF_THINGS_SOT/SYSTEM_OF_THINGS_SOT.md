# System of Things (SoT) — K_HEXSTRIKE

**Project:** `K_HEXSTRIKE`
**Tier:** TIER_6_SECURITY_EVAL
**Domain:** security evaluation, red-team, MITRE ATT&CK, OSINT, threat detection
**Maintainer:** Anticloud FZ LLE · 0-1.gg · lois@0-1.gg · Dubai, UAE
**Model:** Anticloud PAX L5 Narrow L2 General 27B
**AIOSS Chain:** `8b4a8a4f6312dfbe885de8280716985637c163fd2a4b5590341d56db1cc4e560`
**Date:** October 2026

---

## System of Things Architecture

`K_HEXSTRIKE` participates in the Anticloud System of Things (SoT) — a proprioceptive AI architecture that contrasts fundamentally with the nociceptive (stimulus-response) design of current frontier LLMs.

## Proprioceptive vs. Nociceptive

| Architecture | Pattern | `K_HEXSTRIKE` |
|---|---|---|
| **Nociceptive** (frontier LLMs) | Stimulus → Response | Not used |
| **Proprioceptive** (SoT) | Self-state → Prediction → Action → Audit | ✓ Used |

## SoT Component Model for `K_HEXSTRIKE`

```
┌──────────────────────────────────────────────────────────┐
│  K_HEXSTRIKE                                │
│  Tier: TIER_6_SECURITY_EVAL   │
├──────────────────────────────────────────────────────────┤
│  1. Typed Self-State Model                               │
│     → Maintains current component state (health,        │
│       load, compliance status, chain hash)               │
├──────────────────────────────────────────────────────────┤
│  2. Prediction Layer                                     │
│     → Predicts next action before executing              │
│     → Enables pre-flight compliance checks               │
├──────────────────────────────────────────────────────────┤
│  3. Typed Action                                         │
│     → Formally typed input/output interfaces             │
│     → Composable with other SoT components               │
├──────────────────────────────────────────────────────────┤
│  4. AIOSS Audit Entry                                    │
│     → Every action logs to append-only chain             │
│     → H_n = SHA3-256(H_{n-1} ‖ entry_hash_n ‖ ts_n)  │
├──────────────────────────────────────────────────────────┤
│  5. Output                                               │
│     → Produced and typed output returned to caller       │
├──────────────────────────────────────────────────────────┤
│  6. Feedback Loop                                        │
│     → Output feeds back as proprioceptive signal         │
│     → Updates self-state model for next cycle            │
└──────────────────────────────────────────────────────────┘
```

## Why SoT Matters for Compliance

Frontier LLMs produce audit trails as a bolt-on feature. In SoT architecture, the AIOSS chain is the system's own self-model externalized. Compliance is structural, not optional.

This makes `K_HEXSTRIKE` deployments inherently audit-capable without configuration — a critical property for HIPAA, FedRAMP, GDPR, and PCI-DSS regulated environments.

## Integration with PAX 27B

`K_HEXSTRIKE` receives typed inference requests from PAX L5 Narrow L2 General 27B and returns typed, AIOSS-logged outputs. The SoT layer ensures every inference event is:
1. Predicted before execution
2. Logged with full context
3. Verifiable offline via Harvard Dataverse DOI 10.7910/DVN/OORKNJ

**Chain hash:** `8b4a8a4f6312dfbe885de8280716985637c163fd2a4b5590341d56db1cc4e560`
**Contact:** lois@0-1.gg
