# II Budget Envelope

**Project:** `K_HEXSTRIKE`  
**Tier:** TIER_6_SECURITY_EVAL  
**Identity:** Upstream `0x4m4/hexstrike-ai` @ `d689933ff579` (MIT)

## Declared envelope

| Field | Value |
| --- | --- |
| Budget id | II-K_HEXSTRIKE |
| Scope | project |
| Cap | 1500.0 IIU |
| Shadow USD | $37.50 |
| Warn at | 1200 IIU |
| Escalate at | 1425 IIU |
| Red line | none |
| Escalator | operator approval required above escalation threshold |
| Basis | policy (provisional allocation, **not a measured cost**) |

This cap is a **policy allocation**, derived from the project's tier
rather than from an observed run. It is a ceiling to govern against,
not a prediction of what this project costs. A measured figure appears
here only after a run settles into the ledger.

## Why a budget rather than a log

Preprioception is the claim that a cost can be known before the act
that incurs it. If every act is a gesture (ETHICS/01), then each gesture
carries a cost, and the only difference between acting and gambling is
whether that cost was declared first. That the link to preprioception is
our synthesis rather than a claim by Lois-Kleinner Alpasan is recorded
in ETHICS/01; it is a design position and is labelled as one.
