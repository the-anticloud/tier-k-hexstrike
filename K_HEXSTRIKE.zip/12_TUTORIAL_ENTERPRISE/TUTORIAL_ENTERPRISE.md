# Enterprise Tutorial — K_HEXSTRIKE

**Project:** `K_HEXSTRIKE`
**Tier:** TIER_6_SECURITY_EVAL
**Domain:** security evaluation, red-team, MITRE ATT&CK, OSINT, threat detection
**Maintainer:** Anticloud FZ LLE · 0-1.gg · lois@0-1.gg · Dubai, UAE
**Model:** Anticloud PAX L5 Narrow L2 General 27B
**AIOSS Chain:** `8b4a8a4f6312dfbe885de8280716985637c163fd2a4b5590341d56db1cc4e560`
**Date:** October 2026

---

## Enterprise Deployment Guide

This guide is for IT administrators, compliance officers, and enterprise architects deploying `K_HEXSTRIKE` in production regulated environments.

## Pre-Deployment Checklist

- [ ] Anticommons Enterprise License 1.0 signed and received
- [ ] Hardware meets minimum spec: T4 GPU, 32GB RAM, 100GB SSD
- [ ] Network isolation plan documented (air-gap or intranet)
- [ ] AIOSS chain genesis hash verified: `8b4a8a4f6312dfbe885de8280716985637c163fd2a4b5590341d56db1cc4e560`
- [ ] Ed25519 signing keys generated and backed up (3-key quorum)
- [ ] Compliance team briefed on AIOSS audit chain operation

## Deployment Modes

### Mode 1: Full Air-Gap
No network connectivity. All inference, logging, and audit verification local.
```bash
./deploy.sh --mode air-gap --project K_HEXSTRIKE --verify-k5
```

### Mode 2: Secure On-Premise (Intranet)
Inference and audit chain on intranet. No external API calls.
```bash
./deploy.sh --mode on-premise --project K_HEXSTRIKE --network intranet
```

### Mode 3: Hybrid Audit Export
Inference local; AIOSS chain entries optionally exported to external audit ledger.
```bash
./deploy.sh --mode hybrid --project K_HEXSTRIKE --export-chain
```

## Compliance Validation

After deployment, run the compliance validation suite:
```bash
python validate_compliance.py --frameworks gdpr,hipaa,fedramp --project K_HEXSTRIKE
```

Expected outputs:
- GDPR Art. 30 records: PASS
- HIPAA §164.312(b) audit controls: PASS
- FedRAMP AU-9: PASS
- AIOSS chain continuity: PASS

## SLA Terms (Enterprise Tier)

| Metric | SLA |
|---|---|
| Uptime | 99.9% |
| P99 inference latency | ≤ 558ms (T4 GPU) |
| AIOSS chain continuity | Guaranteed |
| Support response | 4 hours (business) / 24 hours (critical) |
| Compliance report turnaround | 5 business days |

**Enterprise support:** lois@0-1.gg · 0-1.gg
